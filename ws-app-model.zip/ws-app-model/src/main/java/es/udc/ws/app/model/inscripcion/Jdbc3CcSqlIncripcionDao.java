package es.udc.ws.app.model.inscripcion;

import java.sql.Connection;

public class Jdbc3CcSqlIncripcionDao extends AbstractSqlInscripcionDao{

    @Override
    public Inscripcion create(Connection connection, Inscripcion inscripcion) {
        return null;
    }
}
