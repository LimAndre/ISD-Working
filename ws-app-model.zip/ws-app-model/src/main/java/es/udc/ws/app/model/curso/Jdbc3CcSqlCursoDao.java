package es.udc.ws.app.model.curso;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;

public class Jdbc3CcSqlCursoDao extends AbstractSqlCursoDao{

    @Override
    public Curso create(Connection connection, Curso curso) {
    return null;
    }

}
