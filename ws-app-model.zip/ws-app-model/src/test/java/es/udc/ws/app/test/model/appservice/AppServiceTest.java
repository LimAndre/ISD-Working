package es.udc.ws.app.test.model.appservice;

public class AppServiceTest {
}
